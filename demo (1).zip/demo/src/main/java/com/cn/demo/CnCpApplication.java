package com.cn.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CnCpApplication {

	public static void main(String[] args) {
		SpringApplication.run(CnCpApplication.class, args);
	}

}
